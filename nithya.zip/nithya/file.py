import re
import csv
from collections import Counter, defaultdict

def parseLogs(filePath):
    with open(filePath, 'r') as file:
        logs = file.readlines()
    return logs

def countRequestsPerIp(logs):
    ipPattern = re.compile(r'^(\d+\.\d+\.\d+\.\d+)')
    ipCounts = Counter(ipPattern.match(log).group(1) for log in logs if ipPattern.match(log))
    return ipCounts

def getMostAccessedEndpoint(logs):
    endpointPattern = re.compile(r'"(?:GET|POST) (\/[^\s]*)')
    endpoints = [endpointPattern.search(log).group(1) for log in logs if endpointPattern.search(log)]
    endpointCounts = Counter(endpoints)
    return endpointCounts  


def detectSuspiciousActivities(logs, threshold=10):
    suspiciousIps = defaultdict(int)
    for log in logs:
        if "401" in log or "Invalid credentials" in log:
            ip = re.match(r'^(\d+\.\d+\.\d+\.\d+)', log).group(1)
            suspiciousIps[ip] += 1
    flaggedIps = {ip: count for ip, count in suspiciousIps.items() if count > threshold}
    return flaggedIps

def saveResultsToCsv(ipCounts, mostAccessed, suspiciousActivities, outputFile):
    with open(outputFile, 'w', newline='') as file:
        writer = csv.writer(file)
        
        writer.writerow(["IP Address", "Request Count"])
        for ip, count in ipCounts.items():
            writer.writerow([ip, count])
        
        writer.writerow([]) 
        
        writer.writerow(["Endpoint", "Access Count"])
        writer.writerow([mostAccessed[0], mostAccessed[1]])
        
        writer.writerow([]) 
        
        writer.writerow(["IP Address", "Failed Login Count"])
        for ip, count in suspiciousActivities.items():
            writer.writerow([ip, count])


def main():
    logFile = './sample log.txt'  
    outputCsv = 'output.csv'
    
    logs = parseLogs(logFile)
    ipCounts = countRequestsPerIp(logs)
    endpointCounts = getMostAccessedEndpoint(logs) 
    suspiciousActivities = detectSuspiciousActivities(logs)
    
 
    print("Requests per IP Address:")
    for ip, count in ipCounts.items():
        print(f"{ip:20} {count}")

    print("\nEndpoint Access Counts:")
    for endpoint, count in endpointCounts.items():
        print(f"{endpoint:30} {count}")
   
    mostAccessed = endpointCounts.most_common(1)[0]
    print("\nMost Frequently Accessed Endpoint:")
    print(f"{mostAccessed[0]} (Accessed {mostAccessed[1]} times)")

    print("\nSuspicious Activity Detected:")
    for ip, count in suspiciousActivities.items():
        print(f"{ip:20} {count}")

    saveResultsToCsv(ipCounts, mostAccessed, suspiciousActivities, outputCsv)
    print(f"\nResults saved to {outputCsv}")

if __name__ == '__main__':
    main()
